package edu.fau.gcasinillo2015.glucotrack;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

public class Profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile2);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



    }

    public void click(View v)
    {
        if(v.getId() == R.id.fbutton)
        {
            Intent i = new Intent(Profile.this, Food.class);
            startActivity(i);
        }

        if(v.getId() == R.id.rbutton)
        {
            Intent i = new Intent(Profile.this, Results.class);
            startActivity(i);
        }




    }

}
