package edu.fau.gcasinillo2015.glucotrack;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

public class MainActivity extends Activity implements OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View informationButton = findViewById(R.id.informationbutton);
        informationButton.setOnClickListener(this);

        View healthytipstbutton = findViewById(R.id.htbutton);
        healthytipstbutton.setOnClickListener(this);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.informationbutton:
                Intent a = new Intent(this, Information.class);
                startActivity(a);
                break;

            case R.id.htbutton:
                Intent b = new Intent(this, Healthytips.class);
                startActivity(b);
                break;
        }

    }

    public void onButtonClick100(View v)
    {
        if(v.getId() == R.id.tbutton)
        {
            Intent i = new Intent(MainActivity.this, TutorialPageOneActivity.class);
            startActivity(i);
        }

        if(v.getId() == R.id.Pbutton)
        {
            Intent i = new Intent(MainActivity.this, Profile.class);
            startActivity(i);
        }
    }
}
