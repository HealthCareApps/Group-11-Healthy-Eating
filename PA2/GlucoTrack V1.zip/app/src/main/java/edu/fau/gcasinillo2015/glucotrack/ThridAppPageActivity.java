package edu.fau.gcasinillo2015.glucotrack;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class ThridAppPageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thrid_app_page);
    }

    public void onButtonClick3(View v)
    {
        if(v.getId() == R.id.Bnext2)
        {
            Intent i = new Intent(ThridAppPageActivity.this, TutorialPageOneActivity.class);
            startActivity(i);
        }
    }
}
