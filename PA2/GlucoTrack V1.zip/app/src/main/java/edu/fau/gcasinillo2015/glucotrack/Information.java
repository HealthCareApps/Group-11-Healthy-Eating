package edu.fau.gcasinillo2015.glucotrack;

import android.os.Bundle;
import android.app.Activity;

public class Information extends Activity
{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.information);
    }
}
