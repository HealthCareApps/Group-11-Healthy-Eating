package edu.fau.gcasinillo2015.something;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;



public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void showFragment(View view)
    {
        MyAlert myAlert = new MyAlert();
        FragmentManager manager = getFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.add(R.id.group, myAlert, "My Alert Fragment");
        transaction.commit();

    }
    public void showFragment2(View view)
    {
        MyAlert myAlert = new MyAlert();
        FragmentManager manager = getFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        transaction.add(R.id.group2, myAlert, "My Alert Fragment");
        transaction.commit();

    }
}
