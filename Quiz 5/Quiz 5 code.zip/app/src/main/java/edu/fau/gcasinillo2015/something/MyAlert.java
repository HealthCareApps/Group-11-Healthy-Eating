package edu.fau.gcasinillo2015.something;

import android.os.Bundle;
import android.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
/**
 * Created by Garvin on 3/9/2016.
 */
public class MyAlert extends DialogFragment
{
    @Override
   public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        return inflater.inflate(R.layout.exercise, null);
    }
}
