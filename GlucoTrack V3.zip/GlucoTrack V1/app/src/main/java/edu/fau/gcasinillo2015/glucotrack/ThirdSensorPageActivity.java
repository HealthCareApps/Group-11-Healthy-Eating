package edu.fau.gcasinillo2015.glucotrack;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class ThirdSensorPageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third_sensor_page);
    }

    public void onButtonClick8(View v)
    {
        if(v.getId() == R.id.Bnext11)
        {
            Intent i = new Intent(ThirdSensorPageActivity.this, TutorialPageOneActivity.class);
            startActivity(i);
        }
    }
}
