package edu.fau.gcasinillo2015.glucotrack;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.view.View.OnClickListener;

public class Healthytips extends Activity implements OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.healthtips);


        View intervention = findViewById(R.id.interventionbutton);
        intervention.setOnClickListener(this);

        View mealplan = findViewById(R.id.mealplanbutton);
        mealplan.setOnClickListener(this);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.interventionbutton:
                Intent z = new Intent(this, Interventions.class);
                startActivity(z);
                break;

            case R.id.mealplanbutton:
                Intent x = new Intent(this, Mealplan.class);
                startActivity(x);
                break;
        }
    }
}





