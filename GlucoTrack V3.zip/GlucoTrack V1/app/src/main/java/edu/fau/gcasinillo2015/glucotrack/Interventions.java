package edu.fau.gcasinillo2015.glucotrack;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Garvin on 3/26/2016.
 */
public class Interventions extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.interventions);
    }
}
