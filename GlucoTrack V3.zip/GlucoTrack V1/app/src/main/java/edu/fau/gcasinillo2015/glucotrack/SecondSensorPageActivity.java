package edu.fau.gcasinillo2015.glucotrack;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class SecondSensorPageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_sensor_page);
    }

    public void onButtonClick4(View v)
    {
        if(v.getId() == R.id.Bnexts1)
        {
            Intent i = new Intent(SecondSensorPageActivity.this, ThirdSensorPageActivity.class);
            startActivity(i);
        }
    }
}
