package edu.fau.gcasinillo2015.glucotrackfinal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "results.db";
    public static final String TABLE_NAME = "results_table";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "MONTH";
    public static final String COL_3 = "DAY";
    public static final String COL_4 = "YEAR";
    public static final String COL_5 = "HOUR";
    public static final String COL_6 = "MINUTES";
    public static final String COL_7 = "BLOODSUGAR";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + TABLE_NAME + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, MONTH INTEGER, DAY INTEGER, YEAR INTEGER, HOUR INTEGER, MINUTES INTEGER, BLOODSUGAR FLOAT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXIST");
        onCreate(db);
    }

    public boolean insertData(String month, String day, String year, String hour, String minutes, String bloodsugar){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2, month);
        contentValues.put(COL_3, day);
        contentValues.put(COL_4, year);
        contentValues.put(COL_5, hour);
        contentValues.put(COL_6, minutes);
        contentValues.put(COL_7, bloodsugar);
        long result = db.insert(TABLE_NAME, null, contentValues);
        if(result == -1)
            return false;
        else
            return true;
    }

    public Cursor getAllData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+TABLE_NAME,null);
        return res;
    }
}
