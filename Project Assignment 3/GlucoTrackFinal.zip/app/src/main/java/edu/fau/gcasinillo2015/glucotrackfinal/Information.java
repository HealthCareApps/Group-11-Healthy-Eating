package edu.fau.gcasinillo2015.glucotrackfinal;

import android.app.Activity;
import android.os.Bundle;


public class Information extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.info);
    }
}
