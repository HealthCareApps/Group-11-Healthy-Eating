package edu.fau.gcasinillo2015.glucotrackfinal;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;


public class appTools extends Activity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle SavedInstanceState){
        super.onCreate(SavedInstanceState);
        setContentView(R.layout.apptools);

        Button launchapp = (Button) findViewById(R.id.myfitbutton);
        launchapp.setOnClickListener(this);

        Button launchapp2 = (Button) findViewById(R.id.goofitbutton);
        launchapp2.setOnClickListener(this);


        Button launchapp3 = (Button) findViewById(R.id.loseitbutton);
        launchapp3.setOnClickListener(this);

        Button launchapp4 = (Button) findViewById(R.id.glucbutton);
        launchapp4.setOnClickListener(this);
    }

    public void onClick(View v) {

        switch(v.getId()) {
            case R.id.myfitbutton:

                Intent a = getPackageManager().getLaunchIntentForPackage("com.myfitnesspal.android");
                if (a != null) {
                    startActivity(a);
                }
                else {
                    a = new Intent(Intent.ACTION_VIEW);
                    a.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    a.setData(Uri.parse("market://details?id=" + "com.myfitnesspal.android"));
                    startActivity(a);
                }
                break;

            case R.id.goofitbutton:
                Intent b = getPackageManager().getLaunchIntentForPackage("com.google.android.apps.fitness");
                if (b != null) {
                    startActivity(b);
                }
                else {
                    b = new Intent(Intent.ACTION_VIEW);
                    b.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    b.setData(Uri.parse("market://details?id=" + "com.google.android.apps.fitness"));
                    startActivity(b);
                }
                break;


            case R.id.loseitbutton:
                Intent c = getPackageManager().getLaunchIntentForPackage("com.fitnow.loseit");
                if (c != null) {
                    startActivity(c);
                }
                else {
                    c = new Intent(Intent.ACTION_VIEW);
                    c.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    c.setData(Uri.parse("market://details?id=" + "com.fitnow.loseit"));
                    startActivity(c);
                }
                break;

            case R.id.glucbutton:
                Intent d = getPackageManager().getLaunchIntentForPackage("com.entrahealth");
                if (d != null) {
                    startActivity(d);
                }
                else {
                    d = new Intent(Intent.ACTION_VIEW);
                    d.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    d.setData(Uri.parse("market://details?id=" + "com.entrahealth"));
                    startActivity(d);
                }
                break;

        }
    }

}
