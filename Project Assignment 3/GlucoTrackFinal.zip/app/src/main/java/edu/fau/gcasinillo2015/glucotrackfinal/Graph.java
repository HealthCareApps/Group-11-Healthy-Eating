package edu.fau.gcasinillo2015.glucotrackfinal;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class Graph extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle SavedInstanceState) {
        super.onCreate(SavedInstanceState);
        setContentView(R.layout.graph);

    }
}
