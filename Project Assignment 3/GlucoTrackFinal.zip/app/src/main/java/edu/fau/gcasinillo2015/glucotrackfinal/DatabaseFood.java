package edu.fau.gcasinillo2015.glucotrackfinal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Stephen on 4/28/2016.
 */
public class DatabaseFood extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "food.db";
    public static final String Table_NAME = "food_table.db";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "FOOD";
    public static final String COL_3 = "Drink";
    public static final String COL_4 = "Medication";

    public DatabaseFood(Context context) {
        super(context, DATABASE_NAME, null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + Table_NAME + " (ID TEXT PRIMARY KEW AUTOINCREMENT,FOOD TEXT,Drink TEXT,Medication TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS"+ Table_NAME);
        onCreate(db);
    }

   public boolean insertData(String food,String drink,String medication) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2,food);
        contentValues.put(COL_3,drink);
        contentValues.put(COL_4, medication);
        long result = db.insert(Table_NAME,null , contentValues);
        if(result == -1)
            return false;
       else
            return true;
    }

    public Cursor getAllData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from "+Table_NAME,null);
        return res;
    }
}
