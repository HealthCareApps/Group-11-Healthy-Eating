package edu.fau.gcasinillo2015.glucotrackfinal;

import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;


public class Tutorial extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle SavedInstanceState) {
        super.onCreate(SavedInstanceState);
        setContentView(R.layout.tutorial);

        ViewPager viewPager = (ViewPager) findViewById(R.id.view_pager3);
        ImageAdapter3 adapter = new ImageAdapter3(this);
        viewPager.setAdapter(adapter);
    }
}
