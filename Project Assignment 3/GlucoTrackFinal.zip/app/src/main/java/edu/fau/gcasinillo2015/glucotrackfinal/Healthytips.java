package edu.fau.gcasinillo2015.glucotrackfinal;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.view.View.OnClickListener;

public class Healthytips extends Activity implements OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.healthtips);

        View intervention = findViewById(R.id.interbutton);
        intervention.setOnClickListener(this);

        View mealplan = findViewById(R.id.mealplan_button);
        mealplan.setOnClickListener(this);

        View healthtools = findViewById(R.id.webbutton);
        healthtools.setOnClickListener(this);

        View apptools = findViewById(R.id.appbutton);
        apptools.setOnClickListener(this);

        View foodguide = findViewById(R.id.foodguidebutton);
        foodguide.setOnClickListener(this);

    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.interbutton:
                Intent z = new Intent(this, Interventions.class);
                startActivity(z);
                break;

            case R.id.mealplan_button:
                Intent x = new Intent(this, MealPlan.class);
                startActivity(x);
                break;

            case R.id.webbutton:
                Intent y = new Intent(this, WebsiteListActivity.class);
                startActivity(y);
                break;

            case R.id.appbutton:
                Intent w = new Intent(this, appTools.class);
                startActivity(w);
                break;

           case R.id.foodguidebutton:
               Intent l = new Intent(this, FoodGuide.class);
               startActivity(l);
               break;

        }
    }

}
