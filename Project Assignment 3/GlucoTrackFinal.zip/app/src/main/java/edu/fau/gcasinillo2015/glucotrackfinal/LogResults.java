package edu.fau.gcasinillo2015.glucotrackfinal;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LogResults extends Activity implements OnClickListener {
    DatabaseHelper myDb;
    EditText editMonth, editDay, editYear, editHour, editMinutes, editBloodsugar;
    Button saveResultsButton;
    Button showSavedResultsButton;

    @Override
    protected void onCreate(Bundle SavedInstanceState) {
        super.onCreate(SavedInstanceState);
        setContentView(R.layout.log_results);
        myDb = new DatabaseHelper(this);

        editMonth = (EditText)findViewById(R.id.editText);
        editDay = (EditText)findViewById(R.id.editText2);
        editYear = (EditText)findViewById(R.id.editText3);
        editHour = (EditText)findViewById(R.id.editText4);
        editMinutes = (EditText)findViewById(R.id.editText5);
        editBloodsugar = (EditText)findViewById(R.id.editText6);
        saveResultsButton = (Button)findViewById(R.id.save_result_button);
        showSavedResultsButton = (Button)findViewById(R.id.show_saved_results_button);
        AddData();
        viewAll();

        View graphbutton = findViewById(R.id.graph_button);
        graphbutton.setOnClickListener(this);
    }

    public void AddData(){
        saveResultsButton.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v){
                       boolean isInserted = myDb.insertData(editMonth.getText().toString(), editDay.getText().toString(), editYear.getText().toString(),
                               editHour.getText().toString(), editMinutes.getText().toString(), editBloodsugar.getText().toString());
                        if(isInserted =true)
                            Toast.makeText(LogResults.this,"Result saved",Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(LogResults.this,"Result not saved",Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    public void viewAll(){
        showSavedResultsButton.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v){
                        Cursor res = myDb.getAllData();
                        if(res.getCount() == 0){
                            showMessage("Error", "No results found");
                            return;
                        }

                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext()){
                            buffer.append("Month : "+ res.getString(1)+"\n");
                            buffer.append("Day : "+ res.getString(2)+"\n");
                            buffer.append("Year : "+ res.getString(3)+"\n");
                            buffer.append("Hour : "+ res.getString(4)+"\n");
                            buffer.append("Minutes : "+ res.getString(5)+"\n");
                            buffer.append("Blood Sugar : "+ res.getString(6)+"\n\n");
                        }
                        showMessage("Results",buffer.toString());
                    }
                }
        );
    }

    public void showMessage(String title, String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }

    public void onClick(View v) {

        switch(v.getId()) {
            case R.id.graph_button:
                Intent a = new Intent(this, Graph.class);
                startActivity(a);
                break;
        }
    }
}
