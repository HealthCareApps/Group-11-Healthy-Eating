package edu.fau.gcasinillo2015.glucotrackfinal;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

public class MainActivity extends Activity implements OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View informationButton = findViewById(R.id.infobutton);
        informationButton.setOnClickListener(this);

        View healthytipstbutton = findViewById(R.id.htbutton);
        healthytipstbutton.setOnClickListener(this);

        View profilebutton = findViewById(R.id.profilebutton);
        profilebutton.setOnClickListener(this);

        View tutorialbutton = findViewById(R.id.tutb);
        tutorialbutton.setOnClickListener(this);
    }

    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.infobutton:
                Intent a = new Intent(this, Information.class);
                startActivity(a);
                break;

            case R.id.htbutton:
                Intent b = new Intent(this, Healthytips.class);
                startActivity(b);
                break;

            case R.id.profilebutton:
                Intent c = new Intent(this, Profile.class);
                startActivity(c);
                break;

            case R.id.tutb:
                Intent d = new Intent(this, Tutorial.class);
                startActivity(d);
                break;
        }
    }


}
