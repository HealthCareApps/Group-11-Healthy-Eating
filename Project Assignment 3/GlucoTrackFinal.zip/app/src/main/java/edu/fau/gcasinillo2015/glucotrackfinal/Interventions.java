package edu.fau.gcasinillo2015.glucotrackfinal;


import android.app.Activity;
import android.os.Bundle;


public class Interventions extends  Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.interventions);
    }
}
