package edu.fau.gcasinillo2015.glucotrackfinal;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

public class Profile extends Activity implements OnClickListener {

    @Override
    protected void onCreate(Bundle SavedInstanceState) {
        super.onCreate(SavedInstanceState);
        setContentView(R.layout.profile);


        View logresultsbutton = findViewById(R.id.log_results_button);
        logresultsbutton.setOnClickListener(this);

        View foodlogbutton = findViewById(R.id.foodlog_buttton);
        foodlogbutton.setOnClickListener(this);

        View updatebutton = findViewById(R.id.update_profilebutton);
        updatebutton.setOnClickListener(this);

        View syncresultsbutton = findViewById(R.id.syncresults_button);
        syncresultsbutton.setOnClickListener(this);

    }
    public void onClick(View v) {

            switch(v.getId()) {
                case R.id.log_results_button:
                    Intent a = new Intent(this, LogResults.class);
                    startActivity(a);
                    break;

                case R.id.foodlog_buttton:
                    Intent b = new Intent(this, foodlog.class);
                    startActivity(b);
                    break;

                case R.id.update_profilebutton:
                    Intent c = new Intent(this, update.class);
                    startActivity(c);
                    break;
        }

        switch(v.getId()) {
            case R.id.syncresults_button:

                Intent a = getPackageManager().getLaunchIntentForPackage("com.example.android.BluetoothChat");

                startActivity(a);

                break;

        }
    }
}