package edu.fau.gcasinillo2015.glucotrackfinal;

import android.app.AlertDialog;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class foodlog extends AppCompatActivity {
    DatabaseFood myDB;
    EditText editFood,editdrink, editMedication;
    Button saveFood;
    Button showFood;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_foodlog);
        myDB = new DatabaseFood(this);

        editFood = (EditText)findViewById(R.id.editText);
        editdrink = (EditText)findViewById(R.id.editText2);
        editMedication = (EditText)findViewById(R.id.editText3);
        saveFood = (Button)findViewById(R.id.save_food_button);
        showFood = (Button)findViewById(R.id.show_food_button);
        AddData();
        viewAll();
    }

    public void AddData() {
        saveFood.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isInserted = myDB.insertData(editFood.getText().toString(),
                                editdrink.getText().toString(),
                                editMedication.getText().toString());
                        if (isInserted = true)
                            Toast.makeText(foodlog.this, "Data Inserted", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(foodlog.this, "Data not Inserted", Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    public void viewAll(){
        showFood.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v){
                        Cursor res = myDB.getAllData();
                        if(res.getCount() == 0){
                            showMessage("Error", "No results found");
                            return;
                        }

                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext()) {
                            buffer.append("Food: " + res.getString(1) + "\n");
                            buffer.append("Drink : " + res.getString(2) + "\n");
                            buffer.append("Medication: " + res.getString(3) + "\n");
                        }

                        showMessage("Results", buffer.toString());
                    }
                }
        );
    }

    public void showMessage(String title, String Message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }

}
