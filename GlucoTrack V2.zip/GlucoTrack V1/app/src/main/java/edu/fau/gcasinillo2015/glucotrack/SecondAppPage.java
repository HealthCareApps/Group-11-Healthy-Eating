package edu.fau.gcasinillo2015.glucotrack;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class SecondAppPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_app_page);
    }

    public void onButtonClick2(View v)
    {
        if(v.getId() == R.id.Bnext1)
        {
            Intent i = new Intent(SecondAppPage.this, ThridAppPageActivity.class);
            startActivity(i);
        }
    }
}
