package edu.fau.gcasinillo2015.glucotrack;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class TutorialPageOneActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tutorial_page_one);
    }

    public void onButtonClick1(View v)
    {
        if(v.getId() == R.id.Bapp)
        {
            Intent i = new Intent(TutorialPageOneActivity.this, SecondAppPage.class);
            startActivity(i);
        }
    }

    public void onButtonClick23(View v)
    {
        if(v.getId() == R.id.button2)
        {
            Intent i = new Intent(TutorialPageOneActivity.this, SecondSensorPageActivity.class);
            startActivity(i);
        }
    }

    public void onButtonClick123(View v)
    {
        if(v.getId() == R.id.button3)
        {
            Intent i = new Intent(TutorialPageOneActivity.this, MainActivity.class);
            startActivity(i);
        }
    }
}
